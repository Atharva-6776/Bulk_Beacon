"""Load category profiles from /profiles/*.json."""
import json
from pathlib import Path

PROFILE_DIR = Path(__file__).resolve().parent.parent / "profiles"


def load_profiles(only=None):
    out = {}
    for f in sorted(PROFILE_DIR.glob("*.json")):
        p = json.loads(f.read_text(encoding="utf-8"))
        if only is None or p["id"] in only:
            out[p["id"]] = p
    return out
