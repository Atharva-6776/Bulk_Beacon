"""Shared data contract. Everyone builds against these shapes."""
from dataclasses import dataclass, field, asdict
from typing import Optional


@dataclass
class Supplier:
    name: str
    source: str                      # "maps" | "marketplace" | "shopping"
    address: str = ""
    lat: Optional[float] = None
    lng: Optional[float] = None
    phone: str = ""
    website: str = ""
    rating: Optional[float] = None
    review_count: int = 0
    open_state: str = ""             # raw Maps text, e.g. "Open ⋅ Closes 8 pm"
    category: str = ""               # Maps business type, e.g. "Wholesaler"
    unit_price: Optional[float] = None
    link: str = ""
    place_id: str = ""
    distance_km: Optional[float] = None
    trust: dict = field(default_factory=dict)           # filled by trust scorer
    rank_breakdown: dict = field(default_factory=dict)  # filled by ranker

    def to_dict(self):
        return asdict(self)


@dataclass
class Request:
    raw_text: str
    item: str = ""
    quantity: Optional[float] = None
    unit: str = "kg"
    city: str = ""
    deadline: str = ""
    urgency: str = "high"
    specs: dict = field(default_factory=dict)
    profile_id: str = ""
